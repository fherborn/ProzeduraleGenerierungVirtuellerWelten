﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

public class VZEditor : EditorWindow {


/*	[MenuItem ("Window/My Window")]
	static void Init () {
		// Get existing open window or if none, make a new one:
		VZEditor window = (VZEditor)EditorWindow.GetWindow (typeof (VZEditor));
		window.Show();
	}
*/



}
